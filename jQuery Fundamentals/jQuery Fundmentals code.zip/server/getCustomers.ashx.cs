﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace jQueryTips.server
{
    /// <summary>
    /// Summary description for getCustomers
    /// </summary>
    public class getCustomers : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "application/json";

            List<Customer> oList = new List<Customer>();

            Customer oCust = new Customer();
            oCust.name = "Robert";
            oCust.id = 1;
            oList.Add(oCust);

            oCust = new Customer();
            oCust.name = "John";
            oCust.id = 3;
            oList.Add(oCust);

            System.Web.Script.Serialization.JavaScriptSerializer js = new System.Web.Script.Serialization.JavaScriptSerializer();
            context.Response.Write(js.Serialize(oList));
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        public class Customer
        {
            public string name;
            public int id;
        }
    }
}