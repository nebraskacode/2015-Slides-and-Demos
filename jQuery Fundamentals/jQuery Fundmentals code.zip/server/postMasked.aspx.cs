﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace jQuery.server
{
    public partial class postMasked : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Write("Date:" + Request.Form["TextBoxDate"].ToString() + "<br />");
            Response.Write("Phone:" + Request.Form["TextBoxPhone"].ToString() + "<br />");
        }
    }
}