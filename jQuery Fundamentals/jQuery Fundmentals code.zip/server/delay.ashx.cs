﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace jQueryTips
{
    /// <summary>
    /// Summary description for delay
    /// </summary>
    public class delay : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            System.Threading.Thread.Sleep(Convert.ToInt32(context.Request.QueryString["ms"]));

            context.Response.ContentType = "text/html";
            context.Response.Write("<h2>Hello World</h2>");
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}