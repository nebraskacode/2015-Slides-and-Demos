﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Linq;

namespace Mobile.code
{
    public class sightInfo
    {
        public int id { get; set; }
        public string name { get; set; }
        public string url { get; set; }
        public string desc { get; set; }
    }

    public class travelSights
    {
        static public IEnumerable<sightInfo> GetSights()
        {
            XDocument xmlDoc = XDocument.Load(HttpContext.Current.Server.MapPath("/app_data/travelSights.xml"));
            var sights = (from sight in xmlDoc.Descendants("sight")
                select new sightInfo
                {
                    id = Convert.ToInt32(sight.Attribute("id").Value),
                    name = sight.Attribute("name").Value,
                    url = sight.Attribute("url").Value,
                    desc = sight.Value
                });

            return sights;
        }
    }
}