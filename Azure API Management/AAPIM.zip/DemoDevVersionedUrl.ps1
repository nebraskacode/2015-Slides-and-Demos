﻿
# Import Functions
. $PSScriptRoot\AAPIM.ps1


$Environment = '' # dev for Dev, test for Test, and leave blank for Production.

$BaseAddress = "https:// AZURE API URL" + $Environment + ".management.azure-api.net/"
$ServiceUrl = "https:// BACKEND SERVICE API URL" + $Environment + ".azurewebsites.net/api/"

$VersionMajor = 0;
$VersionMinor = 3;
$VersionSafeString = "v" + $VersionMajor + "_" + $VersionMinor
$VersionDecimalString = "v" + $versionMajor + "." + $versionMinor

# Get Authorization Access Signature. Get the Identifier and the Primary Key from the Azure API Management Portal on the Security tab.
$Identifier = ''
$PrimaryKey = ''
$Expiry = '04/18/2015 11:16 AM' # Set for a date in the future.
$AS = Get-AAPIMAccesSignature -Identifier $Identifier -Key $PrimaryKey -Expiry $Expiry

# Setup and Create API
$APIID = "MyScriptedAPI" + $VersionSafeString
$APIName = "MyCompanyAPI" + " " + $VersionDecimalString 
$APIDescription = "This API will provide operations that can query some simple dummy data for projects and consultants."
$APIPath = "services/" + $VersionSafeString

$NewAPIResponse = New-AAPIMAPI -BaseAddress $BaseAddress `
            -APIID $APIID `
            -ServiceUrl $ServiceUrl `
            -Path $APIPath `
            -Name $APIName `
            -Description $APIDescription `
            -Protocols @('https') `
            -Authorization $AS

# Setup and Operations
$ProjectsOperationID = "MyScriptedOperationProjects"
$ProjectsOperationName = "Get All Projects"
$ProjectsOperationDescription = "Gets all projects."
$ProjectsOperationHttpMethod = "GET"
$ProjectsOperationUrlTemplate = "/projects"

$NewProjectsOperationResponse = New-AAPIMOperation -BaseAddress $BaseAddress `
                  -APIID $APIID `
                  -OperationID $ProjectsOperationID `
                  -Name $ProjectsOperationName `
                  -Description $ProjectsOperationDescription `
                  -HttpMethod $ProjectsOperationHttpMethod `
                  -UrlTemplate $ProjectsOperationUrlTemplate `
                  -Authorization $AS

$ConsultantsOperationID = "MyScriptedOperationConsultants"
$ConsultantsOperationName = "Get All Consultants"
$ConsultantsOperationDescription = "Gets all consultants."
$ConsultantsOperationHttpMethod = "GET"
$ConsultantsOperationUrlTemplate = "/consultants"

$NewConsultantsOperationResponse = New-AAPIMOperation -BaseAddress $BaseAddress `
                  -APIID $APIID `
                  -OperationID $ConsultantsOperationID `
                  -Name $ConsultantsOperationName `
                  -Description $ConsultantsOperationDescription `
                  -HttpMethod $ConsultantsOperationHttpMethod `
                  -UrlTemplate $ConsultantsOperationUrlTemplate `
                  -Authorization $AS

$RequestsOperationID = "MyScriptedOperationRequests"
$RequestsOperationName = "Get All Requests"
$RequestsOperationDescription = "Gets all requests."
$RequestsOperationHttpMethod = "GET"
$RequestsOperationUrlTemplate = "/requests"

$NewRequestsOperationResponse = New-AAPIMOperation -BaseAddress $BaseAddress `
                  -APIID $APIID `
                  -OperationID $RequestsOperationID `
                  -Name $RequestsOperationName `
                  -Description $RequestsOperationDescription `
                  -HttpMethod $RequestsOperationHttpMethod `
                  -UrlTemplate $RequestsOperationUrlTemplate `
                  -Authorization $AS

# Setup and Create Product
$ProductID = "MyScriptedProduct"
$ProductName = "Basic Package"
$ProductDescription = "This is a basic package containing my Demo API. Its use is limited."
$ProductState = "published"

$NewProductResponse = New-AAPIMProduct -BaseAddress $BaseAddress `
                 -ProductID $ProductID `
                 -Name $ProductName `
                 -Description $ProductDescription `
                 -SubscriptionsLimite 1 `
                 -State $ProductState `
                 -Authorization $AS

# Add API to Product        
$AddAPIToProductResponse = Add-AAPIMAPIToProduct -BaseAddress $BaseAddress `
                      -ProductID $ProductID `
                      -APIID $APIID `
                      -Authorization $AS

# Setup and Add Product Policy
$ProductPolicy = @"
<policies>
    <inbound>
        <base />
        <rate-limit calls="3" renewal-period="60" />
    </inbound>
    <outbound>
        <base />
    </outbound>
</policies>
"@

$NewProductPolicyResponse = New-AAPIMProductPolicy -BaseAddress $BaseAddress `
                       -ProductID $ProductID `
                       -XMLPolicy $ProductPolicy `
                       -Authorization $AS

$APIPolicy = @"
<policies>
    <inbound>
        <base />
        <set-header name="api-version" exists-action="override">
            <value>
"@
$APIPolicy += $VersionDecimalString
$APIPolicy += @"
</value>
        </set-header>
    </inbound>
    <outbound>
        <base />
        <xml-to-json kind="direct" apply="always" consider-accept-header="true" />
    </outbound>
</policies>
"@

$NewAPIPolicyResponse = New-AAPIMAPIPolicy -BaseAddress $BaseAddress `
                   -APIID $APIID `
                   -XMLPolicy $APIPolicy `
                   -Authorization $AS

$CachedOperationPolicy = @"
<policies>
    <inbound>
        <base />
        <cache-lookup vary-by-developer="false" vary-by-developer-groups="false">
			<vary-by-header>Accept</vary-by-header>
		</cache-lookup>
    </inbound>
    <outbound>
        <base />
        <cache-store duration="3600" caching-mode="cache-on" />
    </outbound>
</policies>
"@

$NewProjectsOperationPolicyResponse = New-AAPIMOperationPolicy -BaseAddress $BaseAddress `
                         -APIID $APIID `
                         -OperationID $ProjectsOperationID `
                         -XMLPolicy $CachedOperationPolicy `
                         -Authorization $AS

$NewConsultantsOperationPolicyResponse = New-AAPIMOperationPolicy -BaseAddress $BaseAddress `
                         -APIID $APIID `
                         -OperationID $ConsultantsOperationID `
                         -XMLPolicy $CachedOperationPolicy `
                         -Authorization $AS                    
