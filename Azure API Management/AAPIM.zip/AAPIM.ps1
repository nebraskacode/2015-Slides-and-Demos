﻿function Get-AAPIMAccesSignature {
    Param(
        [String]
        $Identifier,
        [String]
        $Key,
        [DateTime]
        $Expiry
    )
    
    $Expiry = $Expiry.ToUniversalTime()

    $tokenFormat = "SharedAccessSignature uid={0}&ex={1:o}&sn={2}"

    $encoding = [System.Text.Encoding]::UTF8
    $keyBytes = $encoding.GetBytes($Key)

    $encoder = New-Object -TypeName "System.Security.Cryptography.HMACSHA512" -ArgumentList @(,$keyBytes)

    $dataToSign = $Identifier + "`n" + $Expiry.ToString("O", [System.Globalization.CultureInfo]::InvariantCulture)
    $dataBytes = $encoding.GetBytes($dataToSign)

    $hash = $encoder.ComputeHash($dataBytes)
    $signature = [System.Convert]::ToBase64String($hash)

    $token = [String]::Format($tokenFormat, $Identifier, $Expiry, $signature)

    return $token
}

function Invoke-AAPIMRESTfulCall {
    Param(
        [Microsoft.PowerShell.Commands.WebRequestMethod]
        $Method,
        [String]
        $BaseAddress,
        [String]
        $Resource,
        [String[]]
        $QueryParameters,
        [String]
        $ContentType,
        [Hashtable]
        $CustomHeaders,
        [Object]
        $Body,
        [String]
        $Authorization
    )

    # Build and Join Headers
    $headers = @{}
    $headers.Authorization = $Authorization
    
    if ($CustomHeaders) {
        foreach ($key in $CustomHeaders.Keys) {
            if ($headers.ContainsKey($key)) {
                $headers[$key] = $CustomHeaders[$Key]
            } 
            else {
                $headers.Add($Key, $CustomHeaders[$Key])
            }
        }
    }

    # Concatenate Query Parameters
    $version = '2014-02-14'
    $versionQueryParam = $('api-version='+$version)
    if ( -Not $QueryParameters) {
        $QueryParameters = @()
    }
    $QueryParameters += $versionQueryParam
    $queryString = $('?' + [System.String]::Join("&", $QueryParameters))
    $relativeUrl = $($Resource + $queryString)

    # Build URL
    $baseUrl = New-Object -TypeNAme "System.Uri" -ArgumentList $BaseAddress
    $url = New-Object -TypeName "System.Uri" -ArgumentList $baseUrl, $relativeUrl

    if ($Body) {
        if ($ContentType -and $ContentType.ToLower().Contains("json")) {
            $usedBody = $Body | ConvertTo-Json
        }
        else {
            $usedBody = $Body
        }
    }

    $response = Invoke-RestMethod -Method $Method -Uri $url -Headers $headers -ContentType $ContentType -Body $usedBody

    return $response
}

function Get-AAPIMAPIs {
    Param(
        [String]
        $BaseAddress,
        [String]
        $Authorization
    )

    $contentType = "application/json"

    $resource = "apis/"

    $response = Invoke-AAPIMRESTfulCall -Method Get -BaseAddress $BaseAddress -Resource $resource -ContentType $contentType -Authorization $Authorization

    return $response
}

function Get-AAPIMAPI {
    Param(
        [String]
        $BaseAddress,
        [String]
        $APIID,
        [Switch]
        $Export,
        [String]
        $Authorization
    )

    $contentType = "application/json"
    $queryParams = @()

    $resource = $("apis/" + $APIID)

    if ($Export.IsPresent) {
        $queryParams += 'export=true'
    }

    $response = Invoke-AAPIMRESTfulCall -Method Head -BaseAddress $BaseAddress -Resource $resource -QueryParameters $queryParams -ContentType $contentType -Authorization $Authorization

    return $response
}

function New-AAPIMAPI {
    param(
       [String]
       $BaseAddress,
       [String]
       $APIID,
       [String]
       $Name,
       [String]
       $Description,
       [String]
       $ServiceUrl,
       [String]
       $Path,
       [String[]]
       $Protocols,
       [Object[]]
       $Operations,
       [String]
       $ContentType = "application/json",
       [Switch]
       $Import,
       [String]
       $Authorization
    )

    $queryParams = @()

    $resource = $('apis/' + $APIID)

    $body = @{}
    $body.Add('Name', $Name)
    $body.Add('Description', $Description)
    $body.Add('ServiceUrl', $ServiceUrl)
    $body.Add('Path', $Path)
    $body.Add('Protocols', $Protocols)
    if($Operations) {
        $body.Add('Operations', $Operations)
    }

    $response = Invoke-AAPIMRESTfulCall -Method Put -BaseAddress $BaseAddress -Resource $resource -QueryParameters $queryParams -ContentType $ContentType -Body $body -Authorization $Authorization

    return $response
}

function Update-AAPIMAPI {
    param(
       [String]
       $BaseAddress,
       [String]
       $APIID,
       [String]
       $IfMatch = '*',
       [String]
       $Name,
       [String]
       $Description,
       [String]
       $ServiceUrl,
       [String]
       $Path,
       [String[]]
       $Protocols,
       [Object[]]
       $Operations,
       [String]
       $ContentType = "application/json",
       [Switch]
       $Import,
       [String]
       $Authorization
    )

    $queryParams = @()

    $resource = $('apis/' + $APIID)

    $customHeaders = @{}
    $customHeaders.Add('If-Match', $IfMatch)

    $body = @{}
    if ($Name) {$body.Add('name', $Name)}
    if ($Description) {$body.Add('description', $Description)}
    if ($ServiceUrl) {$body.Add('serviceUrl', $ServiceUrl)}
    if ($Path) {$body.Add('path', $Path)}
    if ($Protocols) {$body.Add('protocols', $Protocols)}
    if($Operations) {$body.Add('operations', $Operations)}
    

    $response = Invoke-AAPIMRESTfulCall -Method Patch -BaseAddress $BaseAddress -Resource $resource -QueryParameters $queryParams -CustomHeaders $customHeaders -ContentType $ContentType -Body $body -Authorization $Authorization

    return $response
}

function New-AAPIMOperation {
    param(
       [String]
       $BaseAddress,
       [String]
       $APIID,
       [String]
       $OperationID,
       [String]
       $Name,
       [String]
       $Description,
       [String]
       $HttpMethod,
       [String]
       $UrlTemplate,
       [String]
       $Request,
       [String[]]
       $Responses,
       [String]
       $ContentType = "application/json",
       [String]
       $Authorization
    )

    $resource = $('apis/' + $APIID + '/operations/' + $OperationID)

    $body = @{}
    if ($Name) {$body.Add('name', $Name)}
    if ($Description) {$body.Add('description', $Description)}
    if ($HttpMethod) {$body.Add('method', $HttpMethod)}
    if ($UrlTemplate) {$body.Add('urlTemplate', $UrlTemplate)}
    if ($Request) {$body.Add('request', $Request)}
    if($Responses) {$body.Add('responses', $Responses)}
    

    $response = Invoke-AAPIMRESTfulCall -Method Put -BaseAddress $BaseAddress -Resource $resource -ContentType $ContentType -Body $body -Authorization $Authorization

    return $response
}

function New-AAPIMProductPolicy {
    Param(
        [String]
        $BaseAddress,
        [String]
        $ProductID,
        [String]
        $IfMatch = "*",
        [String]
        $XMLPolicy,
        [String]
        $Authorization
    )
      
    $contentType = 'application/vnd.ms-azure-apim.policy+xml'
    $resource = $('products/' + $ProductID + '/policy')

    $customHeaders = @{}
    $customHeaders.Add('If-Match', $IfMatch)

    $body = $XMLPolicy

    $response = Invoke-AAPIMRESTfulCall -Method Put -BaseAddress $BaseAddress -Resource $resource -CustomHeaders $customHeaders -ContentType $contentType -Body $body -Authorization $Authorization

    return $response

}

function New-AAPIMAPIPolicy {
    Param(
        [String]
        $BaseAddress,
        [String]
        $APIID,
        [String]
        $IfMatch = "*",
        [String]
        $XMLPolicy,
        [String]
        $Authorization
    )
      
    $contentType = 'application/vnd.ms-azure-apim.policy+xml'
    $resource = $('apis/' + $APIID + '/policy')

    $customHeaders = @{}
    $customHeaders.Add('If-Match', $IfMatch)

    $body = $XMLPolicy

    $response = Invoke-AAPIMRESTfulCall -Method Put -BaseAddress $BaseAddress -Resource $resource -CustomHeaders $customHeaders -ContentType $contentType -Body $body -Authorization $Authorization

    return $response

}

function New-AAPIMOperationPolicy {
    Param(
        [String]
        $BaseAddress,
        [String]
        $APIID,
        [String]
        $OperationID,
        [String]
        $IfMatch = "*",
        [String]
        $XMLPolicy,
        [String]
        $Authorization
    )
      
    $contentType = 'application/vnd.ms-azure-apim.policy+xml'
    $resource = $('apis/' + $APIID + '/operations/' + $OperationID + '/policy')

    $customHeaders = @{}
    $customHeaders.Add('If-Match', $IfMatch)

    $body = $XMLPolicy

    $response = Invoke-AAPIMRESTfulCall -Method Put -BaseAddress $BaseAddress -Resource $resource -CustomHeaders $customHeaders -ContentType $contentType -Body $body -Authorization $Authorization

    return $response
}

function New-AAPIMProduct {
    Param(
        [String]
        $BaseAddress,
        [String]
        $ProductID,
        [String]
        $Name,
        [String]
        $Description,
        [String]
        $Terms,
        [Switch]
        $RequiresApproval,
        [int]
        $SubscriptionLimit,
        [String]
        $State,
        [String]
        $Authorization
    )

    $resource = $("products/" + $ProductID)
    $contentType = 'application/json'

    $body = @{}
    $body.Add('name', $Name)
    $body.Add('description', $Description)
    $body.Add('terms', $Terms)
    $body.Add('approvalRequired', $RequiresApproval.IsPresent.ToString().ToLower())
    $body.Add('subscriptionsLimit', $SubscriptionLimit)
    $body.Add('state', $State)

    $response = Invoke-AAPIMRESTfulCall -Method Put -BaseAddress $BaseAddress -Resource $resource -Body $body -ContentType $contentType -Authorization $Authorization

    return $response

}

function Add-AAPIMAPIToProduct {
    Param(
        [String]
        $BaseAddress,
        [String]
        $ProductID,
        [String]
        $APIID,
        [String]
        $Authorization
    )

    $resource = $('/products/' + $ProductID + '/apis/' + $APIID)

    $response = Invoke-AAPIMRESTfulCall -Method Put -BaseAddress $BaseAddress -Resource $resource -Authorization $Authorization

    return $response

}
